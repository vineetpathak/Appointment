'''
Local settings

- Run in Debug mode
'''

from .common import *  # noqa

# Use DEBUG for local development
DEBUG = True
